from openrouteservice.optimization import Vehicle, Job

class FleetManager:
    def __init__(self, bot_count, start):
        self.id = id
        self.start = start
        self.bot_count = 0
        self.bots = self.create_bots(bot_count)
        self.free_bots = self.bots[:]  # Initially, all bots are free

    def create_bots(self, n):
        bots = []
        for i in range(n):
            bots.append(self.create_bot(id=i))
        return bots

    def create_bot(self, id):
        b = Vehicle(id=id, 
                    start=list(reversed(self.start)),
                    end=list(reversed(self.start)),
                    capacity=[500])
        self.bot_count += 1
        return b

    def destroy_bot(self, id):
        for bot in self.bots:
            if bot.id == id:
                self.bots.remove(bot)
                self.bot_count -= 1
                if bot in self.free_bots:
                    self.free_bots.remove(bot)

    def get_bot_count(self):
        return self.bot_count

    def get_available_bot(self):
        if self.free_bots:
            return self.free_bots[0]
        else:
            return None

    def assign_bot(self, bot):
        if bot in self.free_bots:
            self.free_bots.remove(bot)

    def release_bot(self, bot):
        if bot not in self.free_bots:
            self.free_bots.append(bot)
