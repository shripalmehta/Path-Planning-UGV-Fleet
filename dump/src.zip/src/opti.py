import pandas as pd
import openrouteservice as ors
import constants as c
import fleet_manager_2 as fm
import json
import utils

# Initialize the openrouteservice client
client = ors.Client(c.API_KEY)

# Input parameters
postcode = 'LS9 0BT'
bot_count = 2
potholes_data = pd.read_json(r'src/LS90BT_potholes_small.json')

# Search for coordinates corresponding to the given postcode
station = client.pelias_search(text=postcode)
station_coords = station['features'][0]['geometry']['coordinates']

# Initialize fleet manager with the specified number of bots
fleet = fm.FleetManager(bot_count=bot_count, start=list(reversed(station_coords)))

# Initialize utility class
ut = utils.Utils()

# Initialize lists to store job details and pothole estimates
jobs = []
pothole_estimates = []

# Function to get job details for a pothole feature
def get_job_details(feature):
    volume, surface_area, qty_reqd, setup_time, service_time = ut.calculate_eta(feature)
    return ors.optimization.Job(
        location=feature['geometry']['coordinates'],
        id=feature['id'],
        service=service_time,
        amount=[qty_reqd])

# Function to get pothole estimates
def get_pothole_estimate(feature):
    volume, surface_area, qty_reqd, setup_time, service_time = ut.calculate_eta(feature)
    return {
        'id': feature['id'],
        'defect': feature['properties']['defect'],
        'volume': volume,
        'surface_area': surface_area,
        'qty_reqd': qty_reqd,
        'setup_time': setup_time,
        'service_time': service_time}

# Iterate through pothole data to calculate estimates and store job details
for feature in potholes_data['features']:
    job_details = get_job_details(feature)
    jobs.append(job_details)
    pothole_estimate = get_pothole_estimate(feature)
    pothole_estimates.append(pothole_estimate)

route_plans = []

# Optimize the initial route plan
route_plans.append(
                ors.optimization.optimization(
                    client, 
                    jobs=jobs, 
                    vehicles=fleet.bots, 
                    shipments=None, 
                    matrix=None, 
                    geometry=True, 
                    dry_run=None
                )
            )

# Loop until all jobs are assigned
while route_plans[-1]['unassigned']:
    # Get unassigned job IDs
    unassigned_job_ids = [job['id'] for job in route_plans[-1]['unassigned']]
    unassigned_jobs_list = [job for job in jobs if job.id in unassigned_job_ids]

    print('Unassigned jobs:', unassigned_job_ids)

    # get new route plan for remaining jobs
    route_plans.append(ors.optimization.optimization(
                            client, 
                            jobs=unassigned_jobs_list, 
                            vehicles=[fleet.bots], 
                            shipments=None, 
                            matrix=None, 
                            geometry=True, 
                            dry_run=None
                        )
                    )

# Print the final route plan
print("Final route plan:", route_plans)
